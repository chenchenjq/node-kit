/** Preserve Node-native dependencies and svg-captcha's font files at their installed paths. */
export default { serverExternalPackages: ["sms-kit", "svg-captcha", "argon2"] };
